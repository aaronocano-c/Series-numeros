package seriesnumeros;

import java.util.Scanner;

    public class SeriesNumeros {
        
        public void Fibonacci(int lim){
            
            int a = 0, b = 1, c; 
            
            for(int i = 0; i < lim; i++){
                
                System.out.print(a + ", ");
                c = a + b;
                a = b;
                b = c;
            }
        }
        
        public void Padovan(int lim){
           
            long padovan [] = new long[lim];
            padovan[0] = padovan[1] = padovan[2] = 1;
            System.out.print(padovan[0] + ", " + padovan[1] + ", " + padovan[2] + ", ");
            
            for(int i = 3; i < lim; i++){
            
                padovan[i] = padovan[i - 2] + padovan[i - 3];
                System.out.print(padovan[i] + ", ");
            }
        }
        
        public void Pascal(int lim){
        
            int[] arreglo = new int[1];

            for (int i = 1; i < lim; i++) {

                int[] pascal = new int[i];

                for (int j = lim; j > i; j--) {
                    System.out.print(" ");
                }
                
                for (int k = 0; k < i; k++) {
                    if (k == 0 || k == (i - 1)) {
                        pascal[k] = 1;
                }
                    else {

                    pascal[k] = arreglo[k] + arreglo[k - 1];
                    }
                
                System.out.print("[" + pascal[k] + "]");
                }
                
            arreglo = pascal;
            System.out.println();
            }
        }
    public static void main(String[] args) {
        
        SeriesNumeros metodo = new SeriesNumeros();
        Scanner sc = new Scanner(System.in);
        
        int lim, seleccion;
        
        System.out.println("¿Qué serie desea imprimir?");
        System.out.println("Fibonacci = 1 / Padovan = 2 / Pascal = 3");
        seleccion = sc.nextInt();
        System.out.println("Límite de la serie: ");
        lim = sc.nextInt();
        System.out.println("Serie: ");
        
        switch(seleccion){
        
            case 1:
                
                metodo.Fibonacci(lim);
                break;
                
            case 2:
                
                metodo.Padovan(lim);
                break;
                
            case 3:
                
                metodo.Pascal(lim);
                break;
        
        }
    }
}
